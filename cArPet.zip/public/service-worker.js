// Placeholder content for service-worker.js
