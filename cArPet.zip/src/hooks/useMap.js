// Placeholder content for useMap.js
